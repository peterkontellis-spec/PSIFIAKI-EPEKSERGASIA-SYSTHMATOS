ΕΡΓΑΣΤΗΡΙΑΚΗ ΑΣΚΗΣΗ 1 — ΨΗΦΙΑΚΗ ΕΠΕΞΕΡΓΑΣΙΑ ΣΗΜΑΤΟΣ
HMMY458 / ΤΗΛ301 · 2026–2027

ΠΕΡΙΕΧΟΜΕΝΑ
lab1/report.pdf: ελληνική αναφορά με όλα τα διαγράμματα.
lab1/exercise1.py, exercise2.py, exercise3.py: κώδικας των ασκήσεων.
lab1/verify.py: έλεγχοι αριθμητικών αποτελεσμάτων και επανεκτέλεσης.
lab1/requirements.txt: εξαρτήσεις Python.

ΕΚΤΕΛΕΣΗ
Αποσυμπιέστε το ZIP. Ανοίξτε τον φάκελο DSP_Lab1 στο VS Code ή
σε τερματικό. Χρησιμοποιήστε Python 3.12.

macOS / Linux:
python3 -m venv .venv
source .venv/bin/activate

Windows (Command Prompt):
python -m venv .venv
.venv\Scripts\activate.bat

Έπειτα, από τον φάκελο DSP_Lab1:
python -m pip install -r lab1/requirements.txt
python lab1/exercise1.py --fs 1
python lab1/exercise2.py
python lab1/exercise3.py
python lab1/verify.py

Τα διαγράμματα αποθηκεύονται ως εννέα PNG στο lab1/figures.
Οι ελληνικές εικόνες της αναφοράς περιέχουν τα ίδια δεδομένα.
Στο VS Code επιλέξτε τον διερμηνέα Python της .venv.

ΣΥΜΒΑΣΕΙΣ
1Β: η εκφώνηση δεν ορίζει συχνότητα δειγματοληψίας. Για τον άξονα
σε Hz θεωρείται fs = 1 Hz (Ts = 1 s). Η αναφορά εξηγεί την αβεβαιότητα.
3Α: 128 δείγματα στα 256 Hz, με το +30 σε rad.
3Β: 400 δείγματα στα 20 kHz, με φάση 0 rad.

Στην πρώτη σελίδα της αναφοράς υπάρχουν πεδία για τα ονοματεπώνυμα,
τους αριθμούς μητρώου και τον αριθμό ομάδας.
